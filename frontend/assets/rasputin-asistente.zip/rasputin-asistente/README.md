# Rasputín · asistente de IA propio

## Cómo correrlo
1. Instala Node 18 o superior.
2. Crea una API key en console.anthropic.com.
3. En la carpeta del proyecto:
   - Mac/Linux: `ANTHROPIC_API_KEY=tu_clave node server.js`
   - Windows (PowerShell): `$env:ANTHROPIC_API_KEY="tu_clave"; node server.js`
4. Abre http://localhost:3000 en Chrome o Edge.

## Archivos
- `server.js`: backend. Guarda la API key, la memoria (`memory.json`) y las herramientas.
- `persona.js`: personalidad y lore (system prompt).
- `public/index.html`: interfaz (núcleo animado, voz, chat).

## Cómo funciona la lógica
- El navegador manda el historial a `/api/chat`; el servidor añade persona + memoria y llama a la API.
- Si el modelo pide una herramienta, el servidor la ejecuta y le devuelve el resultado (bucle del agente).
- La memoria se guarda en `memory.json` y se inyecta en cada conversación.
- Voz: `SpeechRecognition` (escucha) y `speechSynthesis` (habla), ambas del navegador.

## Ideas para seguir
- Memoria: SQLite, resúmenes automáticos, búsqueda por embeddings.
- Apps: agrega herramientas en `TOOLS` (Google Calendar, Gmail, Notion, domótica) o usa la herramienta de búsqueda web de la API.
- Voz: sustituye `speechSynthesis` por un servicio de TTS más natural.
- Seguridad: nunca pongas la API key en el frontend.
