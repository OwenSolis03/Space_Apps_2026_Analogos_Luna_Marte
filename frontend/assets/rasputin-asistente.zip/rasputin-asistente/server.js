// Servidor mínimo sin dependencias (Node 18+). Guarda tu API key y la memoria.
const http = require("http"), fs = require("fs"), path = require("path");
const PERSONA = require("./persona.js");
const KEY = process.env.ANTHROPIC_API_KEY, MODEL = process.env.MODEL || "claude-sonnet-5-5";
const MEM = path.join(__dirname, "memory.json"), PUB = path.join(__dirname, "public");

// ---- Memoria persistente (un JSON; luego puedes migrar a SQLite) ----
const loadMem = () => { try { return JSON.parse(fs.readFileSync(MEM, "utf8")); } catch { return { facts: [] }; } };
const saveMem = m => fs.writeFileSync(MEM, JSON.stringify(m, null, 2));

// ---- Herramientas: para "conectar apps" agrega aquí más (calendario, correo, domótica...) ----
const TOOLS = [
  { name: "guardar_recuerdo", description: "Guarda un dato duradero sobre el Guardián (gustos, planes, personas, preferencias).",
    input_schema: { type: "object", properties: { dato: { type: "string" } }, required: ["dato"] },
    run: ({ dato }) => { const m = loadMem(); m.facts.push(dato); saveMem(m); return "guardado"; } },
  { name: "olvidar_recuerdo", description: "Borra los recuerdos que contengan este texto.",
    input_schema: { type: "object", properties: { texto: { type: "string" } }, required: ["texto"] },
    run: ({ texto }) => { const m = loadMem(), n = m.facts.length;
      m.facts = m.facts.filter(f => !f.toLowerCase().includes(texto.toLowerCase())); saveMem(m); return "borrados " + (n - m.facts.length); } },
  { name: "hora_actual", description: "Fecha y hora actuales.",
    input_schema: { type: "object", properties: {} },
    run: () => new Date().toLocaleString("es-MX", { dateStyle: "full", timeStyle: "short" }) }
];

// ---- Bucle del agente: modelo -> herramienta -> resultado -> modelo ----
async function chat(messages) {
  const mem = loadMem().facts.map(f => "- " + f).join("\n") || "(vacía)";
  const system = PERSONA + "\n\nMEMORIA (úsala solo si es relevante; guarda con guardar_recuerdo lo duradero que el Guardián te diga):\n" + mem;
  const msgs = [...messages];
  for (let i = 0; i < 5; i++) {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: MODEL, max_tokens: 800, system, messages: msgs,
        tools: TOOLS.map(({ run, ...t }) => t) })
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error?.message || r.status);
    msgs.push({ role: "assistant", content: d.content });
    const calls = d.content.filter(b => b.type === "tool_use");
    if (!calls.length) return d.content.filter(b => b.type === "text").map(b => b.text).join("");
    msgs.push({ role: "user", content: calls.map(c => ({ type: "tool_result", tool_use_id: c.id,
      content: String(TOOLS.find(t => t.name === c.name).run(c.input)) })) });
  }
  return "Demasiados pasos, Guardián.";
}

const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css" };
http.createServer(async (req, res) => {
  if (req.method === "POST" && req.url === "/api/chat") {
    let b = ""; for await (const c of req) b += c;
    res.setHeader("content-type", "application/json");
    try { res.end(JSON.stringify({ text: await chat(JSON.parse(b).messages) })); }
    catch (e) { res.statusCode = 500; res.end(JSON.stringify({ error: e.message })); }
    return;
  }
  const u = new URL(req.url, "http://x").pathname;
  const f = path.join(PUB, path.normalize(u === "/" ? "index.html" : u));
  if (!f.startsWith(PUB)) { res.statusCode = 403; return res.end(); }
  fs.readFile(f, (e, d) => {
    if (e) { res.statusCode = 404; return res.end("404"); }
    res.setHeader("content-type", MIME[path.extname(f)] || "text/plain"); res.end(d);
  });
}).listen(3000, () => console.log("Rasputín en http://localhost:3000"));
